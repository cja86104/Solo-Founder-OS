# `public/fonts/` — self-hosted webfonts

Five Latin-subset `.woff2` files, self-hosted here as of the Tailwind/font
toolchain migration. Sourced via the Fontsource npm packages for the same
three Google Fonts families — same official glyphs, repackaged for
self-hosting. The Fontsource packages themselves are not runtime
dependencies; only the font files were copied out.

| File                                  | Family               | Weight / style |
| -------------------------------------- | --------------------- | -------------- |
| `instrument-serif-400.woff2`           | Instrument Serif       | 400 normal     |
| `instrument-serif-400-italic.woff2`    | Instrument Serif       | 400 italic     |
| `bricolage-grotesque-variable.woff2`   | Bricolage Grotesque    | 200–800 normal |
| `ibm-plex-mono-400.woff2`              | IBM Plex Mono          | 400 normal     |
| `ibm-plex-mono-600.woff2`              | IBM Plex Mono          | 600 normal     |

Referenced from the `@font-face` rules at the top of `src/index.css`, and
`instrument-serif-400.woff2` is preloaded in `index.html` since it paints the
hero headline above the fold. The metric-adjusted `… Fallback` faces further
down in `src/index.css` are unrelated to this directory — they wrap local
system fonts and stay in place regardless.

Vite copies everything under `public/` to the build root verbatim, so the
`/fonts/...` URLs resolve identically in `dev`, `build` and `preview`.
