/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['"Instrument Serif"', '"Instrument Serif Fallback"', 'Georgia', 'serif'],
        sans: [
          '"Bricolage Grotesque"',
          '"Bricolage Grotesque Fallback"',
          'Helvetica Neue',
          'Arial',
          'sans-serif'
        ],
        mono: ['"IBM Plex Mono"', '"IBM Plex Mono Fallback"', 'ui-monospace', 'monospace']
      }
    }
  },
  plugins: []
};
