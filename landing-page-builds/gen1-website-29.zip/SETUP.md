# Founders Helm — landing page

Static marketing page. React 18 + Vite. Tailwind via CDN, Framer Motion for motion, lucide-react for icons.

```bash
npm install
npm run dev     # http://localhost:5173
npm run build
npm run preview
```

Routing uses `HashRouter`, so `/#/signup` and `/#/login` work on any static host with no server config.

---

## What you must swap manually

### 1. Product screenshots (highest priority)
The dashboard/CRM/builder visuals are hand-built React mockups, not real screenshots:

- `src/components/mock/DashboardMock.jsx` — Command Center
- `src/components/mock/CrmMock.jsx` — CRM Kanban
- `src/components/mock/BuilderMock.jsx` — Landing Pages builder
- The AI Advisor chat panel in `src/components/sections/AdvisorSpotlight.jsx`

Replace each with a real capture inside `src/components/ui/BrowserFrame.jsx`. Use an `<img>` with explicit `width`/`height` (or `aspect-ratio`) so nothing shifts, `loading="lazy"` for anything below the fold, and keep the `data-aiwp-slot` numbering intact. There is a visible "Illustrative interface — TODO" note under the advisor panel: delete it once the real screenshot is in.

### 2. Photography — licensing
Five Unsplash photos are referenced in `src/lib/content.js` under `photos`. They are hotlinked from `images.unsplash.com` for prototyping. Before launch:

- self-host the files (or replace with original photography of the actual founder/desk)
- keep the `width` / `height` values accurate to the new files
- alt text is already written per photo — update it if you change the image

Search terms used: *solo entrepreneur laptop night*, *minimalist home office desk*, *founder working late city window*, *hands typing laptop dark room*.

All photos are graded by one shared treatment (`.helm-photo-wrap` + `.helm-duotone` in `src/index.css`) — grayscale, then an orange color-blend and a black falloff. Any new photo dropped into `<Photo />` inherits the same grade automatically, so the set reads as one shoot. Adjust the grade in one place if you want it warmer or cooler.

### 3. Fonts
Loaded from Google Fonts in `index.html`:

- **Instrument Serif** — display headlines (`font-display`)
- **Bricolage Grotesque** — body and UI (`font-sans`)
- **IBM Plex Mono** — kickers, labels, numerals (`font-mono`)

Self-host with `@font-face` + `font-display: swap` for production to drop the third-party request.

### 4. Tailwind
Tailwind is the **CDN build** (`index.html`), with the three font families registered in the inline `tailwind.config`. If you move to the PostCSS/CLI pipeline, port that `fontFamily` block into a real `tailwind.config.js` and add the directives to `src/index.css`.

### 5. Links that are placeholders
- `/signup` and `/login` render `src/pages/Placeholder.jsx` — swap for your real flows.
- Footer link columns currently scroll to the product section (no sub-pages exist yet). Point them at real routes as you build them.
- Nav links, hero CTAs, FAQ "skip" link and the pricing CTAs all work as-is.

---

## Notes on the build

**Content** — every string and data structure lives in `src/lib/content.js`. No copy is inlined in JSX. Nothing is invented beyond the supplied product facts: no testimonials, no customer counts, no fabricated metrics. The single number-heavy moment (the AI Advisor answer) is clearly framed as an illustrative interface.

**Motion** — `src/lib/motion.js` holds the easing set and a live `prefers-reduced-motion` hook. Every animated component checks it and falls back to static. Techniques vary by section on purpose:

- Hero — signature 3D `rotateX` word unfurl + scroll-scrubbed de-skew of the device frame. Used nowhere else.
- Marquee — CSS keyframes, pauses on hover, freezes under reduced motion.
- Pillars — blur-in / horizontal slide / fade-up, different curves per card.
- Deep dives — clip-path mask, slide, blur; each visual gets its own scroll-linked parallax and counter-rotation.
- Pricing — `layoutId` spring pill on the toggle; the focused card scales and lifts.
- Closing — scroll-scrubbed glow saturation.

**Accessibility** — one `<h1>` (hero), sequential heading levels, skip link, visible `:focus-visible` rings, `aria-expanded`/`aria-controls` on the accordion and mobile nav, arrow/Home/End keyboard support in the accordion, `role="tablist"` on the pricing toggle, alt text on every photo and `role="img"` + label on each mockup. Body copy is `#8A8A8A` on `#0A0A0A`/`#0C0C0C` (~5.2:1) and primary text is `#F5F5F0` (~17:1).

**Responsive** — mobile-first from 375px. Checked at 375 / 414 / 768 / 1024 / 1280 / 1920. At 768px the bento drops to a 2-column arrangement and the deep-dive visuals stack above their copy; at 1024px the 12-column asymmetry engages. All CTAs are full-width and tappable on phones — nothing important is hover-only.

**TypeScript** — the brief asked for TS; this ships as JSX so it runs with zero extra install. To convert: rename `.jsx` → `.tsx`, `src/lib/*.js` → `.ts`, add `typescript` + `@types/react` + `@types/react-dom`, and a `tsconfig.json` with `"strict": true`. The data in `content.js` is already shaped for straightforward interface extraction, and there is no `any`-style loose typing anywhere to unpick.