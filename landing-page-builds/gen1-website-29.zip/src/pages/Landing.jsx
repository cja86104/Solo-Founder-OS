import React from 'react';
import Nav from '../components/Nav.jsx';
import Hero from '../components/sections/Hero.jsx';
import StackMarquee from '../components/sections/StackMarquee.jsx';
import Pillars from '../components/sections/Pillars.jsx';
import DeepDives from '../components/sections/DeepDives.jsx';
import AdvisorSpotlight from '../components/sections/AdvisorSpotlight.jsx';
import ProductIndex from '../components/sections/ProductIndex.jsx';
import Pricing from '../components/sections/Pricing.jsx';
import Faq from '../components/sections/Faq.jsx';
import ClosingCta from '../components/sections/ClosingCta.jsx';
import Footer from '../components/sections/Footer.jsx';

export default function Landing() {
  return (
    <div className="relative min-h-screen bg-[#0A0A0A] text-[#F5F5F0] antialiased">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[80] focus:rounded-full focus:bg-[#f97316] focus:px-5 focus:py-2 focus:text-sm focus:font-semibold focus:text-black"
      >
        Skip to content
      </a>
      <Nav />
      <main id="main">
        <Hero />
        <StackMarquee />
        <Pillars />
        <DeepDives />
        <AdvisorSpotlight />
        <ProductIndex />
        <Pricing />
        <Faq />
        <ClosingCta />
      </main>
      <Footer />
    </div>
  );
}