import React, { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import Kicker from '../ui/Kicker.jsx';
import Reveal from '../ui/Reveal.jsx';
import BrowserFrame from '../ui/BrowserFrame.jsx';
import DashboardMock from '../mock/DashboardMock.jsx';
import CrmMock from '../mock/CrmMock.jsx';
import BuilderMock from '../mock/BuilderMock.jsx';
import Photo from '../ui/Photo.jsx';
import { deepDives, photos } from '../../lib/content.js';
import { useReducedMotion, ease } from '../../lib/motion.js';

const mocks = {
  'command-center': { node: <DashboardMock />, url: 'app.foundershelm.com/command-center' },
  crm: { node: <CrmMock />, url: 'app.foundershelm.com/crm/pipeline' },
  'landing-pages': { node: <BuilderMock />, url: 'app.foundershelm.com/pages/launch/edit' }
};

function Visual({ item, index }) {
  const reduced = useReducedMotion();
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start end', 'end start'] });
  const y = useTransform(scrollYProgress, [0, 1], [40, -40]);
  const rotate = useTransform(scrollYProgress, [0, 1], [index % 2 === 0 ? 3 : -3, index % 2 === 0 ? -1.5 : 1.5]);

  const mock = mocks[item.id];

  return (
    <div ref={ref} className="relative">
      {index === 1 && (
        <Photo
          photo={photos.handsTyping}
          slot={3}
          className="absolute -left-3 -top-8 hidden h-40 w-40 rounded-[22px] border border-white/[0.08] lg:block"
        />
      )}
      <motion.div
        style={reduced ? undefined : { y, rotate }}
        className="relative z-10"
      >
        <BrowserFrame url={mock.url}>{mock.node}</BrowserFrame>
      </motion.div>
      <div
        aria-hidden="true"
        className={`pointer-events-none absolute -z-0 h-40 w-40 rounded-full bg-[radial-gradient(circle,rgba(249,115,22,0.4),transparent_70%)] blur-3xl ${
          index % 2 === 0 ? '-bottom-10 -right-6' : '-bottom-10 -left-6'
        }`}
      />
    </div>
  );
}

export default function DeepDives() {
  const revealFor = { scrub: 'mask', slide: 'slideRight', mask: 'blur' };

  return (
    <section aria-labelledby="deepdive-heading" className="relative border-t border-white/[0.06] py-20 sm:py-28 lg:py-32">
      <div className="mx-auto w-full max-w-[1600px] px-5 sm:px-8 lg:px-12">
        <div className="max-w-3xl">
          <Kicker>Inside the platform</Kicker>
          <h2
            id="deepdive-heading"
            className="mt-4 font-display text-[clamp(2.3rem,8.6vw,3.2rem)] leading-[0.92] tracking-[-0.02em] text-[#F5F5F0] sm:text-6xl"
          >
            Four of the ten, in <span className="italic text-[#f97316]">detail</span>.
          </h2>
          <p className="mt-4 max-w-lg text-[15px] leading-relaxed text-[#8A8A8A] sm:text-base">
            The rest are listed further down. These are the ones you’ll open every day.
          </p>
        </div>

        <div className="mt-16 space-y-24 sm:mt-20 sm:space-y-32 lg:space-y-40">
          {deepDives.map((item, index) => {
            const right = item.align === 'right';
            return (
              <article key={item.id} id={item.id} className="grid items-center gap-10 lg:grid-cols-12 lg:gap-12">
                <div
                  className={`lg:col-span-5 ${right ? 'lg:order-1' : 'lg:order-2 lg:col-start-8'}`}
                >
                  <Reveal kind={revealFor[item.reveal]} duration={0.85} curve={ease.out}>
                    <p className="font-mono text-[10px] uppercase tracking-[0.3em] text-[#f97316]">{item.kicker}</p>
                    <h3 className="mt-4 font-display text-[clamp(2rem,7.4vw,2.6rem)] leading-[0.96] tracking-[-0.02em] text-[#F5F5F0] sm:text-5xl">
                      {item.title}{' '}
                      <span className="italic text-[#8A8A8A]">{item.titleAccent}</span>
                    </h3>
                    <p className="mt-5 max-w-md text-[15px] leading-[1.7] text-[#8A8A8A] sm:text-[16px]">{item.body}</p>
                    <ul className="mt-7 space-y-2.5">
                      {item.bullets.map((b) => (
                        <li key={b} className="flex items-start gap-3 text-[14px] text-[#F5F5F0]/85 sm:text-[15px]">
                          <ArrowRight className="mt-1 h-3.5 w-3.5 shrink-0 text-[#f97316]" aria-hidden="true" />
                          {b}
                        </li>
                      ))}
                    </ul>
                  </Reveal>
                </div>

                <div className={`lg:col-span-6 ${right ? 'lg:order-2 lg:col-start-7' : 'lg:order-1'}`}>
                  <Visual item={item} index={index} />
                </div>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
}