import React from 'react';
import Nav from '../components/Nav.jsx';
import Hero from '../components/sections/Hero.jsx';
import StackMarquee from '../components/sections/StackMarquee.jsx';
import Pillars from '../components/sections/Pillars.jsx';
import DeepDives from '../components/sections/DeepDives.jsx';
import AdvisorSpotlight from '../components/sections/AdvisorSpotlight.jsx';
import ProductIndex from '../components/sections/ProductIndex.jsx';
import Pricing from '../components/sections/Pricing.jsx';
import Faq from '../components/sections/Faq.jsx';
import ClosingCta from '../components/sections/ClosingCta.jsx';
import Footer from '../components/sections/Footer.jsx';

/**
 * All sections are static imports — no code-splitting. This was previously
 * behind React.lazy() + Suspense to shrink the initial JS payload (~20% off
 * the main chunk), but that traded reliability for it: if a lazy chunk was
 * slow or failed to resolve, the section silently rendered nothing (the
 * Suspense fallback was a blank div by design), which is exactly what showed
 * up as "the section is just gone" while iterating. Static imports have zero
 * chunk-fetch dependency, so a section is either in the bundle and renders,
 * or the build itself fails loudly. Reintroduce code-splitting later, if
 * wanted, once the design is settled and this is headed toward production.
 */
export default function Landing() {
  return (
    <div className="relative min-h-screen bg-[#0A0A0A] text-[#F5F5F0] antialiased">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[80] focus:rounded-full focus:bg-[#f97316] focus:px-5 focus:py-2 focus:text-sm focus:font-semibold focus:text-black"
      >
        Skip to content
      </a>
      <Nav />
      <main id="main">
        <Hero />
        <StackMarquee />
        <Pillars />
        <DeepDives />
        <AdvisorSpotlight />
        <ProductIndex />
        <Pricing />
        <Faq />
        <ClosingCta />
      </main>
      <Footer />
    </div>
  );
}
