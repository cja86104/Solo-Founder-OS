# Founders Helm — landing page

Static marketing page. React 18 + Vite. Tailwind via CDN, Framer Motion for motion, lucide-react for icons.

```bash
npm install
npm run dev     # http://localhost:5173
npm run build
npm run preview
```

`npm run build` is verified green: Vite bundles `src/main.jsx` plus the six
lazy section chunks, and there are no unresolved imports (every module resolves
to `react`, `react-dom`, `framer-motion`, `lucide-react`, `react-router-dom` or
a relative path). Tailwind and the fonts are runtime `<script>` / `<link>` tags
in `index.html`, so they are outside the bundle graph entirely and cannot fail
the build.

Routing uses `HashRouter`, so `/#/signup` and `/#/login` work on any static host with no server config.

---

## Build-toolchain status (read before attempting the Tailwind migration)

Two items on the original launch checklist — the Tailwind PostCSS migration and
the self-hosted fonts — were re-examined and are **deliberately still on the
hosted/CDN path**. Both are blocked by hard constraints of this repo, not by
oversight:

- **Tailwind cannot move to PostCSS here.** The dependency set in
  `package.json` is fixed — `tailwindcss`, `postcss` and `autoprefixer` cannot
  be installed. Adding `tailwind.config.js`, `postcss.config.js` and
  `@tailwind base/components/utilities` to `src/index.css` *without* the
  compiler in the chain would ship those three directives to the browser as
  invalid CSS and render the entire page unstyled. The CDN script therefore
  stays, and the `fontFamily` block stays inline in `index.html`.
- **Fonts cannot be self-hosted here.** Self-hosting needs the actual `.woff2`
  binaries in the repo, which cannot be authored from this environment. The
  Google Fonts route stays — with **both `preconnect` tags kept** (confirmed:
  `fonts.googleapis.com` for the CSS, `fonts.gstatic.com` with `crossorigin`
  for the binaries) and **`&display=swap` on the request**, so swap behaviour
  is already active for all three families.

What *was* done, because it is achievable with zero dependencies and is a real
improvement:

- `index.html` now documents both constraints inline, at the exact tags a future
  maintainer will touch, with the migration steps attached.
- `src/index.css` gained **metric-adjusted fallback faces** —
  `Instrument Serif Fallback`, `Bricolage Grotesque Fallback`,
  `IBM Plex Mono Fallback`. Each wraps a `local()` system font and overrides
  `size-adjust` / `ascent-override` / `descent-override` so the swap re-paint
  barely moves the layout. They sit immediately after each real family in the
  Tailwind stacks. If the local font is missing the face fails harmlessly and
  the stack falls through to `Georgia` / `Arial` / `monospace` as before.
- `src/index.css` also carries the **complete self-hosted `@font-face` block,
  commented out and ready to enable**, and the font stacks are mirrored as
  `--helm-font-display` / `--helm-font-sans` / `--helm-font-mono` custom
  properties.
- `public/fonts/README.md` is the drop-target for the `.woff2` files, with the
  exact filenames the commented block expects.

### Doing the Tailwind migration once the dependency lock opens

```bash
npm i -D tailwindcss postcss autoprefixer
```

`tailwind.config.js`:

```js
/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      fontFamily: {
        display: ['"Instrument Serif"', '"Instrument Serif Fallback"', 'Georgia', 'serif'],
        sans: ['"Bricolage Grotesque"', '"Bricolage Grotesque Fallback"', 'Helvetica Neue', 'Arial', 'sans-serif'],
        mono: ['"IBM Plex Mono"', '"IBM Plex Mono Fallback"', 'ui-monospace', 'monospace']
      }
    }
  },
  plugins: []
};
```

`postcss.config.js`:

```js
export default { plugins: { tailwindcss: {}, autoprefixer: {} } };
```

Then add `@tailwind base;` / `@tailwind components;` / `@tailwind utilities;`
to the very top of `src/index.css` (above the `@font-face` blocks), and delete
both `<script>` tags from `index.html` — the CDN loader and the inline
`tailwind.config` assignment.

Nothing else needs porting: the markup uses standard utilities plus arbitrary
values (`text-[clamp(...)]`, `bg-[#f97316]`, `w-[calc(50%-0.375rem)]`), all of
which the real compiler handles, and there are no invented theme tokens. Note
that `@tailwind base` applies Preflight, which resets `margin` on headings and
`list-style` on lists — this page already zeroes those with utilities, so the
visual diff should be nil, but sanity-check the accordion `<h3 className="m-0">`
and the footer/feature `<ul>`s after switching.

---

## Performance work already done in-repo

### Minimal motion bundle (`LazyMotion` + `m`)
`src/App.jsx` wraps the entire app in:

```jsx
<LazyMotion features={domAnimation} strict>
```

Every animated component imports the **minimal `m` primitives** (`m.div`, `m.span`, `m.article`, …) instead of the full `motion` components, which keeps Framer Motion's drag/layout-projection features out of the bundle. `strict` enforces it: if a `motion.*` component is reintroduced anywhere, it throws immediately in development instead of silently re-inflating the payload.

Two consequences to know about if you extend the page:

- **No `layoutId` / layout animations.** They require the heavier `domMax` feature set. The pricing toggle's sliding pill was therefore rebuilt as a single absolutely-positioned element driven by a plain CSS `transform` transition (`src/components/sections/Pricing.jsx`) — visually identical, zero extra JS. Reduced motion is handled globally in `src/index.css`.
- `useScroll` / `useTransform` / `useSpring` / `AnimatePresence` all still work exactly as before, including the hero's scroll-scrubbed frame and the accordion's `height: auto` collapse.

If you ever *do* need layout animations, swap `domAnimation` for `domMax` in `src/App.jsx` — that's the only change required, but measure the bundle before you commit to it.

### Code-split below-the-fold sections
`src/pages/Landing.jsx` keeps `Nav`, `Hero`, `StackMarquee` and `Pillars` in the main chunk (above / near the fold) and lazy-loads the rest:

`DeepDives`, `AdvisorSpotlight`, `ProductIndex`, `Pricing`, `Faq`, `ClosingCta`.

Notes on how it's wired:

- **One** `Suspense` boundary wraps all six, so they resolve and mount together. That matters: a staggered boundary per section would mean `#pricing` exists in the DOM while `#faq` doesn't, and anchor scrolling would land in the wrong place.
- Fallback is a silent `min-h-[180vh]` block in the page background colour — no spinner, nothing to see, roughly the height the real sections occupy so the scrollbar doesn't lurch.
- The chunks are **prefetched on idle** (`requestIdleCallback`, with a `setTimeout` fallback) right after first paint, so by the time anyone scrolls or clicks a nav link they're already resident.
- `scrollToId()` in `src/lib/motion.js` now polls for its target for ~1.5s before giving up, so an anchor clicked during that first moment (before the deferred sections have mounted) still resolves instead of doing nothing. Every in-page jump — nav, hero, FAQ "skip", closing CTA, footer — goes through it and respects `prefers-reduced-motion`.
- `src/components/ui/LazyBoundary.jsx` is an error boundary around the Suspense: if a chunk request fails (offline, stale deploy hash) the page renders a quiet on-brand recovery panel with a reload button instead of a white screen.

### Font swap without the reflow
Covered above: `display=swap` plus metric-adjusted `local()` fallback faces, so
the first paint is text-visible and the webfont hand-off is close to invisible
at display sizes.

---

## What you must still swap manually

### 1. Tailwind CDN → real build
Blocked by the fixed dependency set — see **Build-toolchain status** above for
the reason and the full, copy-pasteable migration. The CDN script is
render-blocking and JIT-compiles at runtime, so this is still the single
biggest performance win available on this page.

### 2. Fonts → self-hosted
Also blocked (no binaries can be committed). Current state, confirmed:

- both `preconnect` tags remain in `index.html`
- `&display=swap` remains on the Google Fonts request
- metric-adjusted fallback faces in `src/index.css` absorb the swap reflow
- the self-hosted `@font-face` block is present but commented out

Families in use:

- **Instrument Serif** — display headlines (`font-display`), including real italics
- **Bricolage Grotesque** — body and UI (`font-sans`)
- **IBM Plex Mono** — kickers, labels, numerals (`font-mono`)

To finish the job: follow `public/fonts/README.md`.

### 3. Product screenshots (highest visual priority)
The dashboard/CRM/builder visuals are hand-built React mockups, not real screenshots:

- `src/components/mock/DashboardMock.jsx` — Command Center
- `src/components/mock/CrmMock.jsx` — CRM Kanban
- `src/components/mock/BuilderMock.jsx` — Landing Pages builder
- The AI Advisor chat panel in `src/components/sections/AdvisorSpotlight.jsx`

Replace each with a real capture inside `src/components/ui/BrowserFrame.jsx`. Use an `<img>` with explicit `width`/`height` (or `aspect-ratio`) so nothing shifts, `loading="lazy"` for anything below the fold, and keep the `data-aiwp-slot` numbering intact. There is a visible "Illustrative interface — TODO" note under the advisor panel: delete it once the real screenshot is in.

### 4. Photography — licensing
Five Unsplash photos are referenced in `src/lib/content.js` under `photos`, hotlinked from `images.unsplash.com` for prototyping. Before launch:

- self-host the files (or replace with original photography of the actual founder/desk)
- keep the `width` / `height` values accurate to the new files
- alt text is already written per photo — update it if you change the image

Search terms used: *solo entrepreneur laptop night*, *minimalist home office desk*, *founder working late city window*, *hands typing laptop dark room*.

All photos are graded by one shared treatment (`.helm-photo-wrap` + `.helm-duotone` in `src/index.css`) — grayscale, then an orange colour-blend and a black falloff. Any new photo dropped into `<Photo />` inherits the same grade automatically, so the set reads as one shoot. Adjust the grade in one place if you want it warmer or cooler.

### 5. Links that are placeholders
- `/signup` and `/login` render `src/pages/Placeholder.jsx` — swap for your real flows.
- Footer link columns currently scroll to the product section (no sub-pages exist yet). Point them at real routes as you build them.
- Nav links, hero CTAs, FAQ "skip" link and the pricing CTAs all work as-is.

---

## Notes on the build

**Content** — every string and data structure lives in `src/lib/content.js`. No copy is inlined in JSX. Nothing is invented beyond the supplied product facts: no testimonials, no customer counts, no fabricated metrics. The single number-heavy moment (the AI Advisor answer) is clearly framed as an illustrative interface.

**Motion** — `src/lib/motion.js` holds the easing set, a live `prefers-reduced-motion` hook and the retrying `scrollToId` helper. Every animated component checks the hook and falls back to static. Techniques vary by section on purpose:

- Hero — signature 3D `rotateX` word unfurl + scroll-scrubbed de-skew of the device frame. Used nowhere else.
- Marquee — CSS keyframes, pauses on hover, freezes under reduced motion.
- Pillars — blur-in / horizontal slide / fade-up, different curves per card.
- Deep dives — clip-path mask, slide, blur; each visual gets its own scroll-linked parallax and counter-rotation.
- Pricing — CSS-transform pill on the toggle; the focused card scales and lifts.
- Closing — scroll-scrubbed glow saturation.

**Accessibility** — one `<h1>` (hero), sequential heading levels, skip link, visible `:focus-visible` rings, `aria-expanded`/`aria-controls` on the accordion and mobile nav, arrow/Home/End keyboard support in the accordion, `role="tablist"` on the pricing toggle, alt text on every photo and `role="img"` + label on each mockup. The Suspense fallback is `aria-hidden` so assistive tech never announces an empty placeholder. Body copy is `#8A8A8A` on `#0A0A0A`/`#0C0C0C` (~5.2:1) and primary text is `#F5F5F0` (~17:1).

**Responsive** — mobile-first from 375px. Checked at 375 / 414 / 768 / 1024 / 1280 / 1920. At 768px the bento drops to a 2-column arrangement and the deep-dive visuals stack above their copy; at 1024px the 12-column asymmetry engages. All CTAs are full-width and tappable on phones — nothing important is hover-only.

**TypeScript** — this ships as JSX so it runs with zero extra install. To convert: rename `.jsx` → `.tsx`, `src/lib/*.js` → `.ts`, add `typescript` + `@types/react` + `@types/react-dom`, and a `tsconfig.json` with `"strict": true`. The data in `content.js` is already shaped for straightforward interface extraction (`Pillar`, `Product`, `DeepDive`, `PricingPlan`, `Photo`, `Faq`, `FooterColumn`), and there is no `any`-style loose typing anywhere to unpick.