# `public/fonts/` — drop the self-hosted webfonts here

This directory is the target for step 2 of the launch checklist in `SETUP.md`.
It is empty on purpose: the three families are currently served by Google Fonts
(`index.html`), because the `.woff2` binaries cannot be committed from the
authoring environment.

## What to put in it

Latin-subset `.woff2` files only. Filenames must match the commented
`@font-face` block at the top of `src/index.css`:

| File                                    | Family              | Weight / style |
| --------------------------------------- | ------------------- | -------------- |
| `instrument-serif-400.woff2`            | Instrument Serif    | 400 normal     |
| `instrument-serif-400-italic.woff2`     | Instrument Serif    | 400 italic     |
| `bricolage-grotesque-variable.woff2`    | Bricolage Grotesque | 400–800 normal |
| `ibm-plex-mono-400.woff2`               | IBM Plex Mono       | 400 normal     |
| `ibm-plex-mono-600.woff2`               | IBM Plex Mono       | 600 normal     |

The italic Instrument Serif face is **not optional** — the display headlines
lean on real italics (`italic` on hero/section accents) and synthetic slanting
looks noticeably wrong at 8rem.

## Switching over

1. Copy the files above into this directory.
2. Uncomment the `@font-face` block at the top of `src/index.css`.
3. Delete the Google Fonts `<link>` **and** both `<link rel="preconnect">` tags
   from `index.html` (they are dead weight once nothing is fetched from Google).
4. Optionally add `<link rel="preload" as="font" type="font/woff2" crossorigin
   href="/fonts/instrument-serif-400.woff2">` for the one face that paints
   above the fold.
5. Leave the metric-adjusted `… Fallback` faces in `src/index.css` in place —
   they still smooth the swap re-paint for self-hosted files.

Vite copies everything under `public/` to the build root verbatim, so the
`/fonts/...` URLs resolve identically in `dev`, `build` and `preview`.