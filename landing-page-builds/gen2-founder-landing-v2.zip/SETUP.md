# Founders Helm — landing page

Static marketing page. React 18 + Vite. Tailwind via CDN, Framer Motion for motion, lucide-react for icons.

```bash
npm install
npm run dev     # http://localhost:5173
npm run build
npm run preview
```

Routing uses `HashRouter`, so `/#/signup` and `/#/login` work on any static host with no server config.

---

## Performance work already done in-repo

### Minimal motion bundle (`LazyMotion` + `m`)
`src/App.jsx` wraps the entire app in:

```jsx
<LazyMotion features={domAnimation} strict>
```

Every animated component imports the **minimal `m` primitives** (`m.div`, `m.span`, `m.article`, …) instead of the full `motion` components, which keeps Framer Motion's drag/layout-projection features out of the bundle. `strict` enforces it: if a `motion.*` component is reintroduced anywhere, it throws immediately in development instead of silently re-inflating the payload.

Two consequences to know about if you extend the page:

- **No `layoutId` / layout animations.** They require the heavier `domMax` feature set. The pricing toggle's sliding pill was therefore rebuilt as a single absolutely-positioned element driven by a plain CSS `transform` transition (`src/components/sections/Pricing.jsx`) — visually identical, zero extra JS. Reduced motion is handled globally in `src/index.css`.
- `useScroll` / `useTransform` / `useSpring` / `AnimatePresence` all still work exactly as before, including the hero's scroll-scrubbed frame and the accordion's `height: auto` collapse.

If you ever *do* need layout animations, swap `domAnimation` for `domMax` in `src/App.jsx` — that's the only change required, but measure the bundle before you commit to it.

### Code-split below-the-fold sections
`src/pages/Landing.jsx` keeps `Nav`, `Hero`, `StackMarquee` and `Pillars` in the main chunk (above / near the fold) and lazy-loads the rest:

`DeepDives`, `AdvisorSpotlight`, `ProductIndex`, `Pricing`, `Faq`, `ClosingCta`.

Notes on how it's wired:

- **One** `Suspense` boundary wraps all six, so they resolve and mount together. That matters: a staggered boundary per section would mean `#pricing` exists in the DOM while `#faq` doesn't, and anchor scrolling would land in the wrong place.
- Fallback is a silent `min-h-[180vh]` block in the page background colour — no spinner, nothing to see, roughly the height the real sections occupy so the scrollbar doesn't lurch.
- The chunks are **prefetched on idle** (`requestIdleCallback`, with a `setTimeout` fallback) right after first paint, so by the time anyone scrolls or clicks a nav link they're already resident.
- `scrollToId()` in `src/lib/motion.js` now polls for its target for ~1.5s before giving up, so an anchor clicked during that first moment (before the deferred sections have mounted) still resolves instead of doing nothing. Every in-page jump — nav, hero, FAQ "skip", closing CTA, footer — goes through it and respects `prefers-reduced-motion`.
- `src/components/ui/LazyBoundary.jsx` is an error boundary around the Suspense: if a chunk request fails (offline, stale deploy hash) the page renders a quiet on-brand recovery panel with a reload button instead of a white screen.

---

## What you must still swap manually

### 1. Tailwind CDN → real build (before launch)
Tailwind is currently the **CDN build**, configured inline in `index.html` with the three font families registered under `theme.extend.fontFamily`. That's a render-blocking third-party script and a runtime JIT compile.

To move to the PostCSS pipeline: add `tailwindcss`, `postcss`, `autoprefixer` as dev dependencies, port that inline `fontFamily` block into a real `tailwind.config.js`, create `postcss.config.js`, add `@tailwind base; @tailwind components; @tailwind utilities;` to the top of `src/index.css`, and delete the `<script src="https://cdn.tailwindcss.com">` tag. Everything in the markup uses standard utilities plus arbitrary values (`text-[clamp(...)]`, `bg-[#f97316]`, `w-[calc(50%-0.375rem)]`), all of which the real compiler handles — no invented theme tokens to port.

### 2. Fonts → self-hosted
Loaded from Google Fonts in `index.html`, with `preconnect` to both `fonts.googleapis.com` and `fonts.gstatic.com` (keep those) and `&display=swap` on the request (so swap behaviour is already in place).

- **Instrument Serif** — display headlines (`font-display`)
- **Bricolage Grotesque** — body and UI (`font-sans`)
- **IBM Plex Mono** — kickers, labels, numerals (`font-mono`)

For production, self-host the `.woff2` files, declare them with `@font-face` + `font-display: swap` in `src/index.css`, subset to Latin, and drop the two `preconnect` tags along with the `<link>`.

### 3. Product screenshots (highest visual priority)
The dashboard/CRM/builder visuals are hand-built React mockups, not real screenshots:

- `src/components/mock/DashboardMock.jsx` — Command Center
- `src/components/mock/CrmMock.jsx` — CRM Kanban
- `src/components/mock/BuilderMock.jsx` — Landing Pages builder
- The AI Advisor chat panel in `src/components/sections/AdvisorSpotlight.jsx`

Replace each with a real capture inside `src/components/ui/BrowserFrame.jsx`. Use an `<img>` with explicit `width`/`height` (or `aspect-ratio`) so nothing shifts, `loading="lazy"` for anything below the fold, and keep the `data-aiwp-slot` numbering intact. There is a visible "Illustrative interface — TODO" note under the advisor panel: delete it once the real screenshot is in.

### 4. Photography — licensing
Five Unsplash photos are referenced in `src/lib/content.js` under `photos`, hotlinked from `images.unsplash.com` for prototyping. Before launch:

- self-host the files (or replace with original photography of the actual founder/desk)
- keep the `width` / `height` values accurate to the new files
- alt text is already written per photo — update it if you change the image

Search terms used: *solo entrepreneur laptop night*, *minimalist home office desk*, *founder working late city window*, *hands typing laptop dark room*.

All photos are graded by one shared treatment (`.helm-photo-wrap` + `.helm-duotone` in `src/index.css`) — grayscale, then an orange colour-blend and a black falloff. Any new photo dropped into `<Photo />` inherits the same grade automatically, so the set reads as one shoot. Adjust the grade in one place if you want it warmer or cooler.

### 5. Links that are placeholders
- `/signup` and `/login` render `src/pages/Placeholder.jsx` — swap for your real flows.
- Footer link columns currently scroll to the product section (no sub-pages exist yet). Point them at real routes as you build them.
- Nav links, hero CTAs, FAQ "skip" link and the pricing CTAs all work as-is.

---

## Notes on the build

**Content** — every string and data structure lives in `src/lib/content.js`. No copy is inlined in JSX. Nothing is invented beyond the supplied product facts: no testimonials, no customer counts, no fabricated metrics. The single number-heavy moment (the AI Advisor answer) is clearly framed as an illustrative interface.

**Motion** — `src/lib/motion.js` holds the easing set, a live `prefers-reduced-motion` hook and the retrying `scrollToId` helper. Every animated component checks the hook and falls back to static. Techniques vary by section on purpose:

- Hero — signature 3D `rotateX` word unfurl + scroll-scrubbed de-skew of the device frame. Used nowhere else.
- Marquee — CSS keyframes, pauses on hover, freezes under reduced motion.
- Pillars — blur-in / horizontal slide / fade-up, different curves per card.
- Deep dives — clip-path mask, slide, blur; each visual gets its own scroll-linked parallax and counter-rotation.
- Pricing — CSS-transform pill on the toggle; the focused card scales and lifts.
- Closing — scroll-scrubbed glow saturation.

**Accessibility** — one `<h1>` (hero), sequential heading levels, skip link, visible `:focus-visible` rings, `aria-expanded`/`aria-controls` on the accordion and mobile nav, arrow/Home/End keyboard support in the accordion, `role="tablist"` on the pricing toggle, alt text on every photo and `role="img"` + label on each mockup. The Suspense fallback is `aria-hidden` so assistive tech never announces an empty placeholder. Body copy is `#8A8A8A` on `#0A0A0A`/`#0C0C0C` (~5.2:1) and primary text is `#F5F5F0` (~17:1).

**Responsive** — mobile-first from 375px. Checked at 375 / 414 / 768 / 1024 / 1280 / 1920. At 768px the bento drops to a 2-column arrangement and the deep-dive visuals stack above their copy; at 1024px the 12-column asymmetry engages. All CTAs are full-width and tappable on phones — nothing important is hover-only.

**TypeScript** — this ships as JSX so it runs with zero extra install. To convert: rename `.jsx` → `.tsx`, `src/lib/*.js` → `.ts`, add `typescript` + `@types/react` + `@types/react-dom`, and a `tsconfig.json` with `"strict": true`. The data in `content.js` is already shaped for straightforward interface extraction (`Pillar`, `Product`, `DeepDive`, `PricingPlan`, `Photo`, `Faq`, `FooterColumn`), and there is no `any`-style loose typing anywhere to unpick.