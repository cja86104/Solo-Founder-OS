import React, { Suspense, lazy, useEffect } from 'react';
import Nav from '../components/Nav.jsx';
import Hero from '../components/sections/Hero.jsx';
import StackMarquee from '../components/sections/StackMarquee.jsx';
import Pillars from '../components/sections/Pillars.jsx';
import Footer from '../components/sections/Footer.jsx';
import LazyBoundary from '../components/ui/LazyBoundary.jsx';

/**
 * Above / near the fold — Nav, Hero, StackMarquee, Pillars — ship in the main
 * chunk. Everything below is code-split behind a single Suspense boundary so
 * all six sections resolve together (which keeps in-page anchors intact rather
 * than having #pricing exist before #faq does).
 */
const loaders = {
  deepDives: () => import('../components/sections/DeepDives.jsx'),
  advisor: () => import('../components/sections/AdvisorSpotlight.jsx'),
  productIndex: () => import('../components/sections/ProductIndex.jsx'),
  pricing: () => import('../components/sections/Pricing.jsx'),
  faq: () => import('../components/sections/Faq.jsx'),
  closing: () => import('../components/sections/ClosingCta.jsx')
};

const DeepDives = lazy(loaders.deepDives);
const AdvisorSpotlight = lazy(loaders.advisor);
const ProductIndex = lazy(loaders.productIndex);
const Pricing = lazy(loaders.pricing);
const Faq = lazy(loaders.faq);
const ClosingCta = lazy(loaders.closing);

/** Reserves roughly the height the deferred sections occupy, in page colour. */
function SectionsFallback() {
  return <div aria-hidden="true" className="min-h-[180vh] bg-[#0A0A0A]" />;
}

export default function Landing() {
  useEffect(() => {
    let cancelled = false;
    const prefetch = () => {
      if (cancelled) return;
      Object.values(loaders).forEach((load) => {
        load().catch(() => {
          /* the Suspense boundary + LazyBoundary handle the retry path */
        });
      });
    };

    const idle = window.requestIdleCallback;
    if (typeof idle === 'function') {
      const handle = idle(prefetch, { timeout: 1600 });
      return () => {
        cancelled = true;
        window.cancelIdleCallback?.(handle);
      };
    }

    const timer = window.setTimeout(prefetch, 700);
    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, []);

  return (
    <div className="relative min-h-screen bg-[#0A0A0A] text-[#F5F5F0] antialiased">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[80] focus:rounded-full focus:bg-[#f97316] focus:px-5 focus:py-2 focus:text-sm focus:font-semibold focus:text-black"
      >
        Skip to content
      </a>
      <Nav />
      <main id="main">
        <Hero />
        <StackMarquee />
        <Pillars />
        <LazyBoundary>
          <Suspense fallback={<SectionsFallback />}>
            <DeepDives />
            <AdvisorSpotlight />
            <ProductIndex />
            <Pricing />
            <Faq />
            <ClosingCta />
          </Suspense>
        </LazyBoundary>
      </main>
      <Footer />
    </div>
  );
}