import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import Logo from '../components/ui/Logo.jsx';

export default function Placeholder({ title, body }) {
  return (
    <div className="relative flex min-h-screen flex-col items-start justify-center overflow-hidden bg-[#0A0A0A] px-6 py-24 sm:px-10 lg:px-24">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -left-40 top-1/3 h-[38rem] w-[38rem] rounded-full bg-[#f97316] opacity-[0.13] blur-[140px]"
      />
      <div className="relative z-10 w-full max-w-2xl">
        <Logo />
        <p className="mt-14 font-mono text-[11px] uppercase tracking-[0.32em] text-[#f97316]">
          placeholder route — TODO: connect
        </p>
        <h1 className="mt-5 font-display text-[13vw] leading-[0.88] tracking-tight text-[#F5F5F0] sm:text-6xl lg:text-7xl">
          {title}
        </h1>
        <p className="mt-6 max-w-lg text-[15px] leading-relaxed text-[#8A8A8A] sm:text-base">{body}</p>
        <Link
          to="/"
          className="group mt-10 inline-flex items-center gap-2 rounded-full border border-white/15 px-5 py-3 text-sm font-medium text-[#F5F5F0] transition-colors duration-300 hover:border-[#f97316] hover:text-[#f97316]"
        >
          <ArrowLeft className="h-4 w-4 transition-transform duration-300 group-hover:-translate-x-1" aria-hidden="true" />
          Back to the landing page
        </Link>
      </div>
    </div>
  );
}