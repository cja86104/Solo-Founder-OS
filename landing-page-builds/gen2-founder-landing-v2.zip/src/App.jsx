import React from 'react';
import { HashRouter, Routes, Route } from 'react-router-dom';
import { LazyMotion, domAnimation } from 'framer-motion';
import Landing from './pages/Landing.jsx';
import Placeholder from './pages/Placeholder.jsx';

/**
 * Motion payload: the whole app is wrapped in LazyMotion with the `domAnimation`
 * feature bundle, and every animated component uses the minimal `m` primitives
 * instead of the full `motion` components. `strict` makes that contract
 * enforceable — a stray `motion.div` throws in development rather than silently
 * re-introducing the heavier bundle.
 */
export default function App() {
  return (
    <LazyMotion features={domAnimation} strict>
      <HashRouter>
        <div className="helm-grain-fixed" aria-hidden="true" />
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route
            path="/signup"
            element={
              <Placeholder
                title="Start your 14-day trial"
                body="This is a placeholder route. Wire it to your real signup flow — no credit card is required for the trial."
              />
            }
          />
          <Route
            path="/login"
            element={
              <Placeholder
                title="Welcome back"
                body="This is a placeholder route. Wire it to your real auth (Supabase Auth) when you connect the backend."
              />
            }
          />
          <Route
            path="*"
            element={
              <Placeholder
                title="Nothing here"
                body="That page doesn’t exist yet. Head back to the landing page."
              />
            }
          />
        </Routes>
      </HashRouter>
    </LazyMotion>
  );
}