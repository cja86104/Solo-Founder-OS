import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowUp } from 'lucide-react';
import Logo from '../ui/Logo.jsx';
import { brand, footer } from '../../lib/content.js';
import { scrollToId } from '../../lib/motion.js';

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="relative border-t border-white/[0.07] bg-[#0A0A0A] pb-10 pt-16 sm:pt-20">
      <div className="mx-auto w-full max-w-[1600px] px-5 sm:px-8 lg:px-12">
        <div className="grid gap-12 lg:grid-cols-12 lg:gap-8">
          <div className="lg:col-span-4">
            <Logo />
            <p className="mt-5 max-w-xs text-[14px] leading-relaxed text-[#8A8A8A]">{brand.tagline}</p>
            <button
              type="button"
              onClick={() => scrollToId('top')}
              className="group mt-8 inline-flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.26em] text-[#8A8A8A] transition-colors hover:text-[#f97316]"
            >
              <ArrowUp className="h-3.5 w-3.5 transition-transform duration-300 group-hover:-translate-y-0.5" aria-hidden="true" />
              Back to the top
            </button>
          </div>

          <nav aria-label="Footer" className="grid grid-cols-2 gap-8 sm:grid-cols-3 lg:col-span-7 lg:col-start-6">
            {footer.columns.map((col) => (
              <div key={col.title}>
                <h2 className="font-mono text-[10px] uppercase tracking-[0.26em] text-[#f97316]">{col.title}</h2>
                <ul className="mt-4 space-y-2.5">
                  {col.links.map((link) => (
                    <li key={link}>
                      <Link
                        to="/"
                        onClick={() => scrollToId('product')}
                        className="text-[14px] text-[#8A8A8A] transition-colors duration-300 hover:text-[#F5F5F0]"
                      >
                        {link}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </nav>
        </div>

        <div className="mt-14 flex flex-col gap-3 border-t border-white/[0.07] pt-6 sm:flex-row sm:items-center sm:justify-between">
          <p className="font-mono text-[11px] text-[#5f5f5f]">
            © {year} {brand.name}. All rights reserved.
          </p>
          <p className="font-mono text-[11px] text-[#5f5f5f]">{brand.builtOn}</p>
        </div>
      </div>
    </footer>
  );
}