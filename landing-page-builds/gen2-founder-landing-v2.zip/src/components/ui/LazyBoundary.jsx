import React from 'react';

/**
 * Catches failed dynamic imports (offline, stale deploy hash) so a chunk that
 * never arrives degrades into a quiet, on-brand recovery panel instead of a
 * blank page. Reloading re-requests the manifest.
 */
export default class LazyBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { failed: false };
  }

  static getDerivedStateFromError() {
    return { failed: true };
  }

  componentDidCatch(error) {
    if (typeof console !== 'undefined') {
      console.error('[Founders Helm] section failed to load:', error);
    }
  }

  render() {
    if (this.state.failed) {
      return (
        <section className="border-t border-white/[0.06] bg-[#0C0C0C] px-5 py-24 sm:px-8 lg:px-12">
          <div className="mx-auto w-full max-w-[1600px]">
            <p className="font-mono text-[10px] uppercase tracking-[0.3em] text-[#f97316]">connection interrupted</p>
            <h2 className="mt-4 max-w-xl font-display text-[clamp(2rem,7vw,2.8rem)] leading-[0.95] tracking-tight text-[#F5F5F0]">
              The rest of this page didn’t finish loading.
            </h2>
            <p className="mt-4 max-w-md text-[15px] leading-relaxed text-[#8A8A8A]">
              Everything above still works. Reload to pull the remaining sections down again.
            </p>
            <button
              type="button"
              onClick={() => window.location.reload()}
              className="mt-8 inline-flex items-center gap-2 rounded-full border border-white/15 px-5 py-3 text-sm font-medium text-[#F5F5F0] transition-colors duration-300 hover:border-[#f97316] hover:text-[#f97316]"
            >
              Reload the page
            </button>
          </div>
        </section>
      );
    }

    return this.props.children;
  }
}