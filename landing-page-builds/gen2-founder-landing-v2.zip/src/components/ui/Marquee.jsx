import React from 'react';

export default function Marquee({ items, duration = 38, reverse = false, renderItem, ariaLabel }) {
  const doubled = [...items, ...items];
  return (
    <div className="helm-marquee relative w-full overflow-hidden" aria-label={ariaLabel} role="group">
      <div
        className="helm-marquee-track items-center"
        data-dir={reverse ? 'reverse' : 'forward'}
        style={{ '--helm-marquee-duration': `${duration}s` }}
      >
        {doubled.map((item, i) => (
          <div key={`${item}-${i}`} aria-hidden={i >= items.length ? 'true' : undefined} className="shrink-0">
            {renderItem(item, i)}
          </div>
        ))}
      </div>
      <div aria-hidden="true" className="pointer-events-none absolute inset-y-0 left-0 w-20 bg-gradient-to-r from-[#0A0A0A] to-transparent sm:w-40" />
      <div aria-hidden="true" className="pointer-events-none absolute inset-y-0 right-0 w-20 bg-gradient-to-l from-[#0A0A0A] to-transparent sm:w-40" />
    </div>
  );
}