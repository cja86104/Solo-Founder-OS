import React from 'react';

/**
 * Every photo goes through the same duotone grade so the set reads as one shoot.
 * Explicit width/height prevents layout shift; below-fold photos lazy-load.
 */
export default function Photo({ photo, slot, className = '', imgClassName = '', priority = false, children }) {
  return (
    <div className={`helm-photo-wrap ${className}`}>
      <img
        data-aiwp-slot={slot}
        src={photo.src}
        alt={photo.alt}
        width={photo.width}
        height={photo.height}
        loading={priority ? 'eager' : 'lazy'}
        decoding="async"
        className={`helm-duotone h-full w-full object-cover ${imgClassName}`}
      />
      {children}
    </div>
  );
}