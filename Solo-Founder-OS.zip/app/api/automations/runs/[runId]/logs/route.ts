import { NextRequest, NextResponse } from 'next/server';
import { createClient } from '@/lib/supabase/server';
import type { AutomationLogLevel } from '@/types/automations';

// =============================================================================
// GET /api/automations/runs/[runId]/logs - Get logs for a specific run
// =============================================================================
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ runId: string }> }
) {
  try {
    const supabase = await createClient();
    const { runId } = await params;
    const searchParams = request.nextUrl.searchParams;

    // Authenticate user
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Fetch run to verify access
    const { data: run, error: fetchError } = await (supabase
      .from('automation_runs') as any)
      .select('workspace_id, automation_id')
      .eq('id', runId)
      .single();

    if (fetchError || !run) {
      return NextResponse.json(
        { error: 'Run not found' },
        { status: 404 }
      );
    }

    // Verify workspace membership
    const { data: membership } = await (supabase
      .from('workspace_members') as any)
      .select('role')
      .eq('workspace_id', run.workspace_id)
      .eq('user_id', user.id)
      .single();

    if (!membership) {
      return NextResponse.json(
        { error: 'Not authorized to view these logs' },
        { status: 403 }
      );
    }

    // Build query with filters
    let query = (supabase
      .from('automation_run_logs') as any)
      .select('*', { count: 'exact' })
      .eq('run_id', runId)
      .order('created_at', { ascending: true });

    // Filter by log level
    const level = searchParams.get('level') as AutomationLogLevel | null;
    if (level) {
      query = query.eq('level', level);
    }

    // Filter by action_id
    const actionId = searchParams.get('action_id');
    if (actionId) {
      query = query.eq('action_id', actionId);
    }

    // Pagination
    const limit = parseInt(searchParams.get('limit') || '100', 10);
    const offset = parseInt(searchParams.get('offset') || '0', 10);
    query = query.range(offset, offset + limit - 1);

    const { data: logs, error: logsError, count } = await query;

    if (logsError) {
      console.error('Error fetching logs:', logsError);
      throw logsError;
    }

    // Fetch action details if needed
    const actionIds = [...new Set(
      (logs || [])
        .filter(log => log.action_id)
        .map(log => log.action_id)
    )];

    let actionsMap: Record<string, { action_type: string; position: number }> = {};
    if (actionIds.length > 0) {
      const { data: actions } = await (supabase
        .from('automation_actions') as any)
        .select('id, action_type, position')
        .in('id', actionIds.filter((id): id is string => id !== null));

      if (actions) {
        actionsMap = actions.reduce((acc, action) => {
          acc[action.id] = { action_type: action.action_type, position: action.position };
          return acc;
        }, {} as Record<string, { action_type: string; position: number }>);
      }
    }

    // Enrich logs with action info
    const enrichedLogs = (logs || []).map(log => ({
      ...log,
      action: log.action_id ? actionsMap[log.action_id] || null : null,
    }));

    // Calculate log summary
    type LogRow = { level: string };
    const summary = {
      total: count || 0,
      info: (logs || []).filter((l: LogRow) => l.level === 'info').length,
      warning: (logs || []).filter((l: LogRow) => l.level === 'warning').length,
      error: (logs || []).filter((l: LogRow) => l.level === 'error').length,
      debug: (logs || []).filter((l: LogRow) => l.level === 'debug').length,
    };

    return NextResponse.json({
      logs: enrichedLogs,
      count: count || 0,
      summary,
    });
  } catch (error) {
    console.error('Error in GET /api/automations/runs/[runId]/logs:', error);
    return NextResponse.json(
      { error: 'Failed to fetch logs' },
      { status: 500 }
    );
  }
}

// =============================================================================
// POST /api/automations/runs/[runId]/logs - Add a log entry (for internal use)
// =============================================================================
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ runId: string }> }
) {
  try {
    const supabase = await createClient();
    const { runId } = await params;
    const body = await request.json();

    // Authenticate user
    const { data: { user }, error: authError } = await supabase.auth.getUser();
    if (authError || !user) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Fetch run to verify access
    const { data: run, error: fetchError } = await (supabase
      .from('automation_runs') as any)
      .select('workspace_id')
      .eq('id', runId)
      .single();

    if (fetchError || !run) {
      return NextResponse.json(
        { error: 'Run not found' },
        { status: 404 }
      );
    }

    // Verify workspace membership with editor+ role
    const { data: membership } = await (supabase
      .from('workspace_members') as any)
      .select('role')
      .eq('workspace_id', run.workspace_id)
      .eq('user_id', user.id)
      .single();

    if (!membership) {
      return NextResponse.json(
        { error: 'Not authorized to add logs' },
        { status: 403 }
      );
    }

    if (membership.role === 'viewer') {
      return NextResponse.json(
        { error: 'Insufficient permissions' },
        { status: 403 }
      );
    }

    // Validate input
    const { level, message, action_id, details } = body;

    if (!level || !message) {
      return NextResponse.json(
        { error: 'level and message are required' },
        { status: 400 }
      );
    }

    const validLevels: AutomationLogLevel[] = ['info', 'warning', 'error', 'debug'];
    if (!validLevels.includes(level)) {
      return NextResponse.json(
        { error: `Invalid level. Must be one of: ${validLevels.join(', ')}` },
        { status: 400 }
      );
    }

    // Create log entry
    const { data: log, error: logError } = await (supabase
      .from('automation_run_logs') as any)
      .insert({
        run_id: runId,
        action_id: action_id || null,
        level,
        message,
        details: details || {},
      })
      .select()
      .single();

    if (logError) {
      console.error('Error creating log:', logError);
      throw logError;
    }

    return NextResponse.json({ log }, { status: 201 });
  } catch (error) {
    console.error('Error in POST /api/automations/runs/[runId]/logs:', error);
    return NextResponse.json(
      { error: 'Failed to create log entry' },
      { status: 500 }
    );
  }
}
